-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ludeb
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ludeb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ludeb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `ludeb`;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_action` (`action`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `system_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=516 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'Table Creation',NULL,'Created audit_logs table','2025-07-28 20:15:03'),(2,'User Creation',1,'Created system administrator: Admin','2025-07-28 20:15:04'),(3,'User Creation',2,'Created user: Nelson, Role: Data Entrant','2025-07-28 20:15:04'),(4,'System Setup',1,'Completed initial system setup','2025-07-28 20:15:04'),(5,'Login Attempt',NULL,'Failed: No user found for admin@ludeb.com','2025-07-28 20:15:23'),(6,'Login Success',1,'User Admin logged in','2025-07-28 20:16:13'),(7,'Dashboard Access',1,'Accessed dashboard','2025-07-28 20:16:13'),(8,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 20:16:13'),(9,'Page Access',1,'Accessed page: Add School','2025-07-28 20:16:22'),(10,'Page Access',1,'Accessed page: Add School','2025-07-28 20:16:33'),(11,'Page Access',1,'Accessed page: Add School','2025-07-28 20:17:11'),(12,'Page Access',1,'Accessed page: Add School','2025-07-28 20:17:14'),(13,'Login Success',2,'User Nelson logged in','2025-07-28 20:19:18'),(14,'Dashboard Access',2,'Accessed dashboard','2025-07-28 20:19:18'),(15,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 20:19:29'),(16,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 20:19:29'),(17,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 20:19:34'),(18,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 20:19:34'),(19,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 20:19:37'),(20,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 20:19:37'),(21,'Page Access',1,'Accessed page: Add School','2025-07-28 20:24:37'),(22,'Page Access',1,'Accessed page: Add School','2025-07-28 20:24:39'),(23,'Dashboard Access',1,'Accessed dashboard','2025-07-28 20:24:40'),(24,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 20:24:40'),(25,'Logout',1,'User Admin logged out','2025-07-28 20:24:48'),(26,'Login Success',1,'User Admin logged in','2025-07-28 20:25:03'),(27,'Dashboard Access',1,'Accessed dashboard','2025-07-28 20:25:03'),(28,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 20:25:03'),(29,'Add User Access',1,'System Admin accessed add user page','2025-07-28 20:25:20'),(30,'Add User Access',1,'System Admin accessed add user page','2025-07-28 20:25:27'),(31,'Manage Users Access',1,'System Admin accessed manage users page','2025-07-28 20:25:28'),(32,'Add Daily Target',1,'Added target for date: 2025-07-28, exam year ID: 1, entries: 2400','2025-07-28 20:25:55'),(33,'Dashboard Access',2,'Accessed dashboard','2025-07-28 20:26:04'),(34,'Dashboard Access',1,'Accessed dashboard','2025-07-28 20:28:54'),(35,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 20:28:54'),(36,'Page Access',1,'Accessed page: Add School','2025-07-28 20:28:56'),(37,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:29:05'),(38,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:29:05'),(39,'Page Access',1,'Accessed page: Add School','2025-07-28 20:29:12'),(40,'Page Access',1,'Accessed page: Add School','2025-07-28 20:43:21'),(41,'Page Access',1,'Accessed page: Add School','2025-07-28 20:43:23'),(42,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:43:27'),(43,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:43:27'),(44,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:43:50'),(45,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:43:50'),(46,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:46:13'),(47,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:46:13'),(48,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:46:14'),(49,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:46:14'),(50,'Page Access',1,'Accessed page: Add School','2025-07-28 20:46:16'),(51,'Page Access',1,'Accessed page: Add School','2025-07-28 20:46:24'),(52,'Page Access',1,'Accessed page: Add School','2025-07-28 20:46:38'),(53,'Page Access',1,'Accessed page: Add School','2025-07-28 20:49:30'),(54,'Page Access',1,'Accessed page: Add School','2025-07-28 20:49:30'),(55,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:51:57'),(56,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:51:57'),(57,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:52:09'),(58,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:52:09'),(59,'Page Access',1,'Accessed page: Add School','2025-07-28 20:52:11'),(60,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:52:23'),(61,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:52:23'),(62,'Page Access',1,'Accessed page: Add School','2025-07-28 20:52:44'),(63,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 20:58:58'),(64,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 20:58:58'),(65,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 21:01:35'),(66,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 21:01:35'),(67,'Page Access',1,'Accessed page: Add School','2025-07-28 21:01:40'),(68,'Page Access',1,'Accessed page: Add School','2025-07-28 21:02:55'),(69,'Page Access',1,'Accessed page: Add School','2025-07-28 21:03:04'),(70,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 21:03:13'),(71,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 21:03:13'),(72,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 21:03:17'),(73,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 21:03:17'),(74,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 21:06:12'),(75,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 21:06:12'),(76,'Page Access',1,'Accessed page: Add School','2025-07-28 21:06:15'),(77,'Import School',1,'Imported/Updated school: KIMANTO PRIMARY SCHOOL (Center: 002123)','2025-07-28 21:06:24'),(78,'Import School',1,'Imported/Updated school: BUDONDO PRIMARY SCHOOL (Center: 002124)','2025-07-28 21:06:24'),(79,'Import School',1,'Imported/Updated school: LUKUNHU MOSLEM PRIMARY SCHOOL (Center: 002126)','2025-07-28 21:06:24'),(80,'Import School',1,'Imported/Updated school: BUSALAMU PRIMARY SCHOOL (Center: 002127)','2025-07-28 21:06:24'),(81,'Import School',1,'Imported/Updated school: TABINGWA PRIMARY SCHOOL (Center: 002128)','2025-07-28 21:06:24'),(82,'Import School',1,'Imported/Updated school: BUWOLOGOMA PRIMARY SCHOOL (Center: 002130)','2025-07-28 21:06:24'),(83,'Import School',1,'Imported/Updated school: BUKADDE PRIMARY SCHOOL (Center: 002131)','2025-07-28 21:06:24'),(84,'Import School',1,'Imported/Updated school: NDHOYA PRIMARY SCHOOL (Center: 002132)','2025-07-28 21:06:24'),(85,'Import School',1,'Imported/Updated school: BIGUNHO PRIMARY SCHOOL (Center: 002134)','2025-07-28 21:06:24'),(86,'Import School',1,'Imported/Updated school: KIROBA PRIMARY SCHOOL (Center: 002135)','2025-07-28 21:06:24'),(87,'Import School',1,'Imported/Updated school: NAKABONDO PRIMARY SCHOOL (Center: 002136)','2025-07-28 21:06:24'),(88,'Import School',1,'Imported/Updated school: BUDOMA PRIMARY SCHOOL (Center: 002137)','2025-07-28 21:06:24'),(89,'Import School',1,'Imported/Updated school: WALYEMBWA PRIMARY SCHOOL (Center: 002138)','2025-07-28 21:06:24'),(90,'Import School',1,'Imported/Updated school: BUKANGA PRIMARY SCHOOL (Center: 002139)','2025-07-28 21:06:24'),(91,'Import School',1,'Imported/Updated school: NAMUKUBEMBE PRIMARY SCHOOL (Center: 002140)','2025-07-28 21:06:24'),(92,'Import School',1,'Imported/Updated school: BUKANHA PRIMARY SCHOOL (Center: 002141)','2025-07-28 21:06:24'),(93,'Import School',1,'Imported/Updated school: BUKYANGWA PRIMARY SCHOOL (Center: 002142)','2025-07-28 21:06:24'),(94,'Import School',1,'Imported/Updated school: BUKOOVA ST.MARY\'S PRI. SCHOOL (Center: 002143)','2025-07-28 21:06:24'),(95,'Import School',1,'Imported/Updated school: BUSANDA PRIMARY SCHOOL (Center: 002144)','2025-07-28 21:06:24'),(96,'Import School',1,'Imported/Updated school: ST.THOMAS MUKUTU PRI. SCHOOL (Center: 002145)','2025-07-28 21:06:24'),(97,'Import School',1,'Imported/Updated school: NAIRIKA PRIMARY SCHOOL (Center: 002147)','2025-07-28 21:06:24'),(98,'Import School',1,'Imported/Updated school: NAIGOBYA PRIMARY SCHOOL (Center: 002148)','2025-07-28 21:06:24'),(99,'Import School',1,'Imported/Updated school: BUSAKU PRIMARY SCHOOL (Center: 002149)','2025-07-28 21:06:24'),(100,'Import School',1,'Imported/Updated school: KIRIMWA PRIMARY SCHOOL (Center: 002150)','2025-07-28 21:06:24'),(101,'Import School',1,'Imported/Updated school: NAMULANDA PRIMARY SCHOOL (Center: 002151)','2025-07-28 21:06:24'),(102,'Import School',1,'Imported/Updated school: GWEMBUZI PRIMARY SCHOOL (Center: 002152)','2025-07-28 21:06:24'),(103,'Import School',1,'Imported/Updated school: NAWANSEGA PRIMARY SCHOOL (Center: 002153)','2025-07-28 21:06:24'),(104,'Import School',1,'Imported/Updated school: BUDHABANGULA PRIMARY SCHOOL (Center: 002156)','2025-07-28 21:06:24'),(105,'Import School',1,'Imported/Updated school: NAMUMERA PRIMARY SCHOOL (Center: 002157)','2025-07-28 21:06:24'),(106,'Import School',1,'Imported/Updated school: BUGONYOKA PRIMARY SCHOOL (Center: 002158)','2025-07-28 21:06:24'),(107,'Import School',1,'Imported/Updated school: NABITAAMA PRIMARY SCHOOL (Center: 002160)','2025-07-28 21:06:24'),(108,'Import School',1,'Imported/Updated school: BUKENDI PRIMARY SCHOOL (Center: 002161)','2025-07-28 21:06:24'),(109,'Import School',1,'Imported/Updated school: BUGABULA PRIMARY SCHOOL (Center: 002162)','2025-07-28 21:06:24'),(110,'Import School',1,'Imported/Updated school: MAWEMBE PRIMARY SCHOOL (Center: 002163)','2025-07-28 21:06:24'),(111,'Import School',1,'Imported/Updated school: KIYUNGA PRIMARY SCHOOL (Center: 002165)','2025-07-28 21:06:24'),(112,'Import School',1,'Imported/Updated school: KAMWIRUNGU PRIMARY SCHOOL (Center: 002166)','2025-07-28 21:06:24'),(113,'Import School',1,'Imported/Updated school: KITWEKYAMBOGO PRIMARY SCHOOL (Center: 002167)','2025-07-28 21:06:24'),(114,'Import School',1,'Imported/Updated school: BUYUNZE PRIMARY SCHOOL (Center: 002170)','2025-07-28 21:06:24'),(115,'Import School',1,'Imported/Updated school: BUSALA PRIMARY SCHOOL (Center: 002171)','2025-07-28 21:06:24'),(116,'Import School',1,'Imported/Updated school: NAKABUGU PRIMARY SCHOOL (Center: 002172)','2025-07-28 21:06:24'),(117,'Import School',1,'Imported/Updated school: IKUMBYA PRIMARY SCHOOL (Center: 002173)','2025-07-28 21:06:24'),(118,'Import School',1,'Imported/Updated school: IKUMBYA CATHOLIC PRI. SCHOOL (Center: 002174)','2025-07-28 21:06:24'),(119,'Import School',1,'Imported/Updated school: BUGAMBO PRIMARY SCHOOL (Center: 002176)','2025-07-28 21:06:24'),(120,'Import School',1,'Imported/Updated school: BUDHUUBA PRIMARY SCHOOL (Center: 002177)','2025-07-28 21:06:24'),(121,'Import School',1,'Imported/Updated school: WANDAGO PRIMARY SCHOOL (Center: 002178)','2025-07-28 21:06:24'),(122,'Import School',1,'Imported/Updated school: BUNAFU PRIMARY SCHOOL (Center: 002179)','2025-07-28 21:06:24'),(123,'Import School',1,'Imported/Updated school: NAWAKA PRIMARY SCHOOL (Center: 002180)','2025-07-28 21:06:24'),(124,'Import School',1,'Imported/Updated school: NTAYIGIRWA PRIMARY SCHOOL (Center: 002181)','2025-07-28 21:06:24'),(125,'Import School',1,'Imported/Updated school: BUKOBBO PRIMARY SCHOOL (Center: 002182)','2025-07-28 21:06:24'),(126,'Import School',1,'Imported/Updated school: IRONGO PRIMARY SCHOOL (Center: 002183)','2025-07-28 21:06:24'),(127,'Import School',1,'Imported/Updated school: LAMBALA PRIMARY SCHOOL (Center: 002184)','2025-07-28 21:06:24'),(128,'Import School',1,'Imported/Updated school: NAIMULI PRIMARY SCHOOL (Center: 002185)','2025-07-28 21:06:24'),(129,'Import School',1,'Imported/Updated school: KALYOWA PRIMARY SCHOOL (Center: 002187)','2025-07-28 21:06:24'),(130,'Import School',1,'Imported/Updated school: NAKAVUMA PRIMARY SCHOOL (Center: 002188)','2025-07-28 21:06:24'),(131,'Import School',1,'Imported/Updated school: NKANDAKULYOWA PRIMARY SCHOOL (Center: 002189)','2025-07-28 21:06:24'),(132,'Import School',1,'Imported/Updated school: KIWALAZI PRIMARY SCHOOL (Center: 002191)','2025-07-28 21:06:24'),(133,'Import School',1,'Imported/Updated school: NAKABAALE PRIMARY SCHOOL (Center: 002192)','2025-07-28 21:06:24'),(134,'Import School',1,'Imported/Updated school: BUTOGONYA PRIMARY SCHOOL (Center: 002194)','2025-07-28 21:06:24'),(135,'Import School',1,'Imported/Updated school: BUYEMBA PRIMARY SCHOOL (Center: 002195)','2025-07-28 21:06:24'),(136,'Import School',1,'Imported/Updated school: BUWANDA PRIMARY SCHOOL (Center: 002196)','2025-07-28 21:06:24'),(137,'Import School',1,'Imported/Updated school: NAWANDYO PRIMARY SCHOOL(LUUKA) (Center: 002197)','2025-07-28 21:06:24'),(138,'Import School',1,'Imported/Updated school: BUGOMBA PRIMARY SCHOOL (Center: 002198)','2025-07-28 21:06:24'),(139,'Import School',1,'Imported/Updated school: BUYOOLA PRIMARY SCHOOL (Center: 002199)','2025-07-28 21:06:24'),(140,'Import School',1,'Imported/Updated school: IKONIA PRIMARY SCHOOL (Center: 002200)','2025-07-28 21:06:24'),(141,'Import School',1,'Imported/Updated school: NABIKUYI PRIMARY SCHOOL (Center: 002202)','2025-07-28 21:06:24'),(142,'Import School',1,'Imported/Updated school: NAMAGERA PRIMARY SCHOOL (Center: 002203)','2025-07-28 21:06:24'),(143,'Import School',1,'Imported/Updated school: NAWAMPITI PRIMARY SCHOOL (Center: 002204)','2025-07-28 21:06:24'),(144,'Import School',1,'Imported/Updated school: KITUUTO PRIMARY SCHOOL (Center: 002205)','2025-07-28 21:06:24'),(145,'Import School',1,'Imported/Updated school: NAWANKOMPE PRIMARY SCHOOL (Center: 002208)','2025-07-28 21:06:24'),(146,'Import School',1,'Imported/Updated school: BUSIIRO PRIMARY SCHOOL (Center: 002209)','2025-07-28 21:06:24'),(147,'Import School',1,'Imported/Updated school: BUSIIRO MUSLIM PRIMARY SCHOOL (Center: 002211)','2025-07-28 21:06:24'),(148,'Import School',1,'Imported/Updated school: BUTIMBWA PRIMARY SCHOOL (Center: 002212)','2025-07-28 21:06:24'),(149,'Import School',1,'Imported/Updated school: NAMAKAKALE PRIMARY SCHOOL (Center: 002213)','2025-07-28 21:06:24'),(150,'Import School',1,'Imported/Updated school: WAIBUGA MUSLIM PRIMARY SCHOOL (Center: 002214)','2025-07-28 21:06:24'),(151,'Import School',1,'Imported/Updated school: WAIBUGA PRIMARY SCHOOL (Center: 002216)','2025-07-28 21:06:24'),(152,'Import School',1,'Imported/Updated school: BUWIIRI PRIMARY SCHOOL (Center: 002217)','2025-07-28 21:06:24'),(153,'Import School',1,'Imported/Updated school: KAKUMBI PRIMARY SCHOOL (Center: 002218)','2025-07-28 21:06:24'),(154,'Import School',1,'Imported/Updated school: NAMADOPE PRIMARY SCHOOL (Center: 002219)','2025-07-28 21:06:24'),(155,'Import School',1,'Imported/Updated school: BULANGA PRIMARY SCHOOL (Center: 002221)','2025-07-28 21:06:24'),(156,'Import School',1,'Imported/Updated school: MAUNDO PRIMARY SCHOOL (Center: 002222)','2025-07-28 21:06:24'),(157,'Import School',1,'Imported/Updated school: BULANGA NAHADHAT PRI. SCHOOL (Center: 002223)','2025-07-28 21:06:24'),(158,'Import School',1,'Imported/Updated school: WALIBO PRIMARY SCHOOL (Center: 002225)','2025-07-28 21:06:24'),(159,'Import School',1,'Imported/Updated school: BUDHAANA PRIMARY SCHOOL (Center: 080012)','2025-07-28 21:06:24'),(160,'Import School',1,'Imported/Updated school: KIYUNGA PARENTS PRIMARY SCHOOL (Center: 080013)','2025-07-28 21:06:24'),(161,'Import School',1,'Imported/Updated school: BUYOGA PRIMARY SCHOOL (Center: 080048)','2025-07-28 21:06:24'),(162,'Import School',1,'Imported/Updated school: BULAWA PRIMARY SCHOOL (Center: 080071)','2025-07-28 21:06:24'),(163,'Import School',1,'Imported/Updated school: KYANVUMA PRIMARY SCHOOL (Center: 080072)','2025-07-28 21:06:24'),(164,'Import School',1,'Imported/Updated school: BUGONZA PRIMARY SCHOOL (Center: 080073)','2025-07-28 21:06:24'),(165,'Import School',1,'Imported/Updated school: ROADSIDE PRIMARY SCHOOL (Center: 080079)','2025-07-28 21:06:24'),(166,'Import School',1,'Imported/Updated school: ST.KIZITO KAWANGA P/S (Center: 080093)','2025-07-28 21:06:24'),(167,'Import School',1,'Imported/Updated school: NABYOTO PRIMARY SCHOOL (Center: 080095)','2025-07-28 21:06:24'),(168,'Import School',1,'Imported/Updated school: ST.ALICE BUDOMA STAR PRIMARY SCHOOL (Center: 080104)','2025-07-28 21:06:24'),(169,'Import School',1,'Imported/Updated school: NABIMOGO PRIMARY SCHOOL (Center: 080125)','2025-07-28 21:06:24'),(170,'Import School',1,'Imported/Updated school: SAAWE VICTORY PRIMARY SCHOOL (Center: 080152)','2025-07-28 21:06:24'),(171,'Import School',1,'Imported/Updated school: IKONIA PARENTS PRIMARY SCHOOL (Center: 950002)','2025-07-28 21:06:24'),(172,'Import School',1,'Imported/Updated school: MARIAM MEMORIAL PRIMARY SCHOOL (Center: 950003)','2025-07-28 21:06:24'),(173,'Import School',1,'Imported/Updated school: HEALING CHILDREN SCHOOL (Center: 950054)','2025-07-28 21:06:24'),(174,'Import School',1,'Imported/Updated school: NEW HOPE PRIMARY SCHOOL (Center: 950063)','2025-07-28 21:06:24'),(175,'Import School',1,'Imported/Updated school: NAMULANDA MODEL PRIMARY SCHOOL (Center: 950069)','2025-07-28 21:06:24'),(176,'Import School',1,'Imported/Updated school: BUDHUUBA MODERN PRIMARY SCHOOL (Center: 950073)','2025-07-28 21:06:24'),(177,'Import School',1,'Imported/Updated school: SHALOM CHRISTIAN BOARDING P/S (Center: 950080)','2025-07-28 21:06:24'),(178,'Import School',1,'Imported/Updated school: B. M PRIMARY SCHOOL (Center: 950081)','2025-07-28 21:06:24'),(179,'Import School',1,'Imported/Updated school: EDEN JUNIOR SCHOOL,KIYUNGA (Center: 950082)','2025-07-28 21:06:24'),(180,'Import School',1,'Imported/Updated school: BULIKE COMMUNITY SCHOOL (Center: 950094)','2025-07-28 21:06:24'),(181,'Import School',1,'Imported/Updated school: ST.ALOYSIOUS PRIMARY SCHOOL,LUUKA (Center: 950101)','2025-07-28 21:06:24'),(182,'Import School',1,'Imported/Updated school: KIYUNGA VILLAGE PRIMARY SCHOOL (Center: 950180)','2025-07-28 21:06:24'),(183,'Page Access',1,'Accessed page: Add School','2025-07-28 21:06:24'),(184,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 21:06:36'),(185,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 21:06:36'),(186,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 21:07:10'),(187,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 21:07:10'),(188,'View School Access',1,'System Admin accessed view school page','2025-07-28 21:07:13'),(189,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 21:07:13'),(190,'View School Access',1,'System Admin accessed view school page','2025-07-28 21:07:25'),(191,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 21:07:25'),(192,'View School Access',1,'System Admin accessed view school page','2025-07-28 21:07:30'),(193,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 21:07:30'),(194,'View School Access',1,'System Admin accessed view school page','2025-07-28 21:07:46'),(195,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 21:07:46'),(196,'View School Access',1,'System Admin accessed view school page','2025-07-28 21:12:19'),(197,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 21:12:19'),(198,'View School Access',1,'System Admin accessed view school page','2025-07-28 21:12:34'),(199,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 21:12:34'),(200,'View School Access',1,'System Admin accessed view school page','2025-07-28 22:51:01'),(201,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 22:51:01'),(202,'View School Access',1,'System Admin accessed view school page','2025-07-28 22:51:18'),(203,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 22:51:18'),(204,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:09:00'),(205,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:09:00'),(206,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:09:13'),(207,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:09:13'),(208,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:29'),(209,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:29'),(210,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:40'),(211,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:40'),(212,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:41'),(213,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:41'),(214,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:41'),(215,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:41'),(216,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:42'),(217,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:42'),(218,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:42'),(219,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:42'),(220,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:42'),(221,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:42'),(222,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:43'),(223,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:43'),(224,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:17:43'),(225,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:17:43'),(226,'Upload Candidate',1,'Uploaded/Updated candidate: ASIO CHARITY MARY (Index: 950081/001) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(227,'Upload Candidate',1,'Uploaded/Updated candidate: ATIANG ESTHER (Index: 950081/002) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(228,'Upload Candidate',1,'Uploaded/Updated candidate: AYANGA PROSSY (Index: 950081/003) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(229,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE SHAMIM NAKAGOLO (Index: 950081/004) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(230,'Upload Candidate',1,'Uploaded/Updated candidate: BAIDYE PRECIOUS GIFT (Index: 950081/005) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(231,'Upload Candidate',1,'Uploaded/Updated candidate: BANGI BENJAMIN (Index: 950081/006) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(232,'Upload Candidate',1,'Uploaded/Updated candidate: BEBINA SILAT (Index: 950081/007) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(233,'Upload Candidate',1,'Uploaded/Updated candidate: BIKUMBI ALPHA JOSHUA (Index: 950081/008) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(234,'Upload Candidate',1,'Uploaded/Updated candidate: BITIRA PROSSY (Index: 950081/009) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(235,'Upload Candidate',1,'Uploaded/Updated candidate: BULAGO SAMUEL (Index: 950081/010) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(236,'Upload Candidate',1,'Uploaded/Updated candidate: GALUBAALE JAMES (Index: 950081/011) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(237,'Upload Candidate',1,'Uploaded/Updated candidate: IGOYOOLA GILSOM (Index: 950081/012) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(238,'Upload Candidate',1,'Uploaded/Updated candidate: KADAKI EMMANUEL (Index: 950081/013) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(239,'Upload Candidate',1,'Uploaded/Updated candidate: KALULU KAMUYATI (Index: 950081/014) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(240,'Upload Candidate',1,'Uploaded/Updated candidate: KASUUBO NOVERT (Index: 950081/015) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(241,'Upload Candidate',1,'Uploaded/Updated candidate: KIRABO TRACY (Index: 950081/016) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(242,'Upload Candidate',1,'Uploaded/Updated candidate: KISAKYE CATHERINE (Index: 950081/017) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(243,'Upload Candidate',1,'Uploaded/Updated candidate: KISAMBIRA KELVIN (Index: 950081/018) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(244,'Upload Candidate',1,'Uploaded/Updated candidate: KWAGALA TRACY (Index: 950081/019) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(245,'Upload Candidate',1,'Uploaded/Updated candidate: LUKOLOBE YONAH (Index: 950081/020) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(246,'Upload Candidate',1,'Uploaded/Updated candidate: MAKIITA MARK PRAISE (Index: 950081/021) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(247,'Upload Candidate',1,'Uploaded/Updated candidate: MUNUNUZI TITUS (Index: 950081/022) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(248,'Upload Candidate',1,'Uploaded/Updated candidate: MUZAYA SHAMIRU (Index: 950081/023) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(249,'Upload Candidate',1,'Uploaded/Updated candidate: MUZAYA TREVIS (Index: 950081/024) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(250,'Upload Candidate',1,'Uploaded/Updated candidate: MWESIGWA GOSHENS (Index: 950081/025) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(251,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGENDE MARIAM KISAKYE (Index: 950081/026) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(252,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGWE ESTHER (Index: 950081/027) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(253,'Upload Candidate',1,'Uploaded/Updated candidate: NAKABUYE HAIRAT (Index: 950081/028) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(254,'Upload Candidate',1,'Uploaded/Updated candidate: NAKASANGO SAYIDA (Index: 950081/029) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(255,'Upload Candidate',1,'Uploaded/Updated candidate: NAMUGANZA MILLY (Index: 950081/030) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(256,'Upload Candidate',1,'Uploaded/Updated candidate: NANGOBI DAPHINE (Index: 950081/031) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(257,'Upload Candidate',1,'Uploaded/Updated candidate: NANKWANGA SHARON (Index: 950081/032) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(258,'Upload Candidate',1,'Uploaded/Updated candidate: OKUMU WISDOM (Index: 950081/033) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(259,'Upload Candidate',1,'Uploaded/Updated candidate: SSUUBI KELLY (Index: 950081/034) for school ID 102, exam_year_id 1','2025-07-28 23:18:00'),(260,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:24:36'),(261,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:24:36'),(262,'Dashboard Access',1,'Accessed dashboard','2025-07-28 23:24:52'),(263,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 23:24:52'),(264,'Dashboard Access',1,'Accessed dashboard','2025-07-28 23:28:16'),(265,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 23:28:16'),(266,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:28:18'),(267,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:28:18'),(268,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:28:30'),(269,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:28:30'),(270,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:28:33'),(271,'Page Access',1,'Accessed page: View School: B. M PRIMARY SCHOOL','2025-07-28 23:28:33'),(272,'Download File',1,'Downloaded file: B._M_PRIMARY_SCHOOL_1753733880.xlsx (ID: 1) for school ID 102','2025-07-28 23:28:41'),(273,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:28:56'),(274,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:28:56'),(275,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:29:02'),(276,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:29:02'),(277,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:29:04'),(278,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:29:04'),(279,'Upload Candidate',1,'Uploaded/Updated candidate: AJWANGI DINAH (Index: 002127/001) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(280,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE CLARE (Index: 002127/002) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(281,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE MARION (Index: 002127/003) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(282,'Upload Candidate',1,'Uploaded/Updated candidate: BAKAAKI ISMA (Index: 002127/004) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(283,'Upload Candidate',1,'Uploaded/Updated candidate: BAKULIMYA RACHAEL (Index: 002127/005) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(284,'Upload Candidate',1,'Uploaded/Updated candidate: BASOOMYE BASHIRI (Index: 002127/006) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(285,'Upload Candidate',1,'Uploaded/Updated candidate: BAZAALE JACOB MULUNGI (Index: 002127/007) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(286,'Upload Candidate',1,'Uploaded/Updated candidate: BIRABWA AZIZA (Index: 002127/008) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(287,'Upload Candidate',1,'Uploaded/Updated candidate: ISABIRYE CYRUS (Index: 002127/009) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(288,'Upload Candidate',1,'Uploaded/Updated candidate: ISABIRYE FELIX (Index: 002127/010) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(289,'Upload Candidate',1,'Uploaded/Updated candidate: ISIIKO RAYMOND (Index: 002127/011) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(290,'Upload Candidate',1,'Uploaded/Updated candidate: KAGOYA SANIA (Index: 002127/012) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(291,'Upload Candidate',1,'Uploaded/Updated candidate: KALEMBE SHARIFAH (Index: 002127/013) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(292,'Upload Candidate',1,'Uploaded/Updated candidate: KAUDHA GLORIA (Index: 002127/014) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(293,'Upload Candidate',1,'Uploaded/Updated candidate: KIBOGO MUSA (Index: 002127/015) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(294,'Upload Candidate',1,'Uploaded/Updated candidate: KIRIMWA COLLINE (Index: 002127/016) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(295,'Upload Candidate',1,'Uploaded/Updated candidate: KIVEINUMA ABEL (Index: 002127/017) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(296,'Upload Candidate',1,'Uploaded/Updated candidate: KWEDUSA SARAH (Index: 002127/018) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(297,'Upload Candidate',1,'Uploaded/Updated candidate: MAGUNDA YOWERI (Index: 002127/019) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(298,'Upload Candidate',1,'Uploaded/Updated candidate: MATENDE SHAFIC (Index: 002127/020) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(299,'Upload Candidate',1,'Uploaded/Updated candidate: MIREMBE MARIAM (Index: 002127/021) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(300,'Upload Candidate',1,'Uploaded/Updated candidate: MUDOBI ISA (Index: 002127/022) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(301,'Upload Candidate',1,'Uploaded/Updated candidate: MUGOGO SHAKULU (Index: 002127/023) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(302,'Upload Candidate',1,'Uploaded/Updated candidate: MUTAMBA MORIS (Index: 002127/024) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(303,'Upload Candidate',1,'Uploaded/Updated candidate: MUTESI FLAVIA (Index: 002127/025) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(304,'Upload Candidate',1,'Uploaded/Updated candidate: MUTESI SWABURAH (Index: 002127/026) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(305,'Upload Candidate',1,'Uploaded/Updated candidate: NABUKALU SAFINA (Index: 002127/027) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(306,'Upload Candidate',1,'Uploaded/Updated candidate: NABWIRE PRETTY FORTUNATE (Index: 002127/028) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(307,'Upload Candidate',1,'Uploaded/Updated candidate: NABIRE STELLA (Index: 002127/029) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(308,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA GLORIA (Index: 002127/030) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(309,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA MARIA (Index: 002127/031) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(310,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA RESTY (Index: 002127/032) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(311,'Upload Candidate',1,'Uploaded/Updated candidate: NAISIGA TRACY (Index: 002127/033) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(312,'Upload Candidate',1,'Uploaded/Updated candidate: NAKACHWA DOCUS (Index: 002127/034) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(313,'Upload Candidate',1,'Uploaded/Updated candidate: NAKISIGE SHEIRA (Index: 002127/035) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(314,'Upload Candidate',1,'Uploaded/Updated candidate: NAMBOGWE PATRICIA (Index: 002127/036) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(315,'Upload Candidate',1,'Uploaded/Updated candidate: NAMUKOSE AMINA (Index: 002127/037) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(316,'Upload Candidate',1,'Uploaded/Updated candidate: NANFUNA SHEIRA (Index: 002127/038) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(317,'Upload Candidate',1,'Uploaded/Updated candidate: NGOBI DENIS (Index: 002127/039) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(318,'Upload Candidate',1,'Uploaded/Updated candidate: NGOBI MAJORINE (Index: 002127/040) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(319,'Upload Candidate',1,'Uploaded/Updated candidate: NYIIRO AKIRAM (Index: 002127/041) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(320,'Upload Candidate',1,'Uploaded/Updated candidate: OBBO RONALD (Index: 002127/042) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(321,'Upload Candidate',1,'Uploaded/Updated candidate: SSEMBERA CALVIN JORDAN (Index: 002127/043) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(322,'Upload Candidate',1,'Uploaded/Updated candidate: TIBITONDWA DAMALI (Index: 002127/044) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(323,'Upload Candidate',1,'Uploaded/Updated candidate: SOMOKA JOVAN (Index: 002127/045) for school ID 4, exam_year_id 1','2025-07-28 23:29:21'),(324,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:29:30'),(325,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:29:30'),(326,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:29:46'),(327,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:29:46'),(328,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:29:50'),(329,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:29:50'),(330,'Upload Candidate',1,'Uploaded/Updated candidate: AJWANGI DINAH (Index: 002127/001) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(331,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE CLARE (Index: 002127/002) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(332,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE MARION (Index: 002127/003) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(333,'Upload Candidate',1,'Uploaded/Updated candidate: BAKAAKI ISMA (Index: 002127/004) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(334,'Upload Candidate',1,'Uploaded/Updated candidate: BAKULIMYA RACHAEL (Index: 002127/005) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(335,'Upload Candidate',1,'Uploaded/Updated candidate: BASOOMYE BASHIRI (Index: 002127/006) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(336,'Upload Candidate',1,'Uploaded/Updated candidate: BAZAALE JACOB MULUNGI (Index: 002127/007) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(337,'Upload Candidate',1,'Uploaded/Updated candidate: BIRABWA AZIZA (Index: 002127/008) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(338,'Upload Candidate',1,'Uploaded/Updated candidate: ISABIRYE CYRUS (Index: 002127/009) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(339,'Upload Candidate',1,'Uploaded/Updated candidate: ISABIRYE FELIX (Index: 002127/010) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(340,'Upload Candidate',1,'Uploaded/Updated candidate: ISIIKO RAYMOND (Index: 002127/011) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(341,'Upload Candidate',1,'Uploaded/Updated candidate: KAGOYA SANIA (Index: 002127/012) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(342,'Upload Candidate',1,'Uploaded/Updated candidate: KALEMBE SHARIFAH (Index: 002127/013) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(343,'Upload Candidate',1,'Uploaded/Updated candidate: KAUDHA GLORIA (Index: 002127/014) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(344,'Upload Candidate',1,'Uploaded/Updated candidate: KIBOGO MUSA (Index: 002127/015) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(345,'Upload Candidate',1,'Uploaded/Updated candidate: KIRIMWA COLLINE (Index: 002127/016) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(346,'Upload Candidate',1,'Uploaded/Updated candidate: KIVEINUMA ABEL (Index: 002127/017) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(347,'Upload Candidate',1,'Uploaded/Updated candidate: KWEDUSA SARAH (Index: 002127/018) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(348,'Upload Candidate',1,'Uploaded/Updated candidate: MAGUNDA YOWERI (Index: 002127/019) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(349,'Upload Candidate',1,'Uploaded/Updated candidate: MATENDE SHAFIC (Index: 002127/020) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(350,'Upload Candidate',1,'Uploaded/Updated candidate: MIREMBE MARIAM (Index: 002127/021) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(351,'Upload Candidate',1,'Uploaded/Updated candidate: MUDOBI ISA (Index: 002127/022) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(352,'Upload Candidate',1,'Uploaded/Updated candidate: MUGOGO SHAKULU (Index: 002127/023) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(353,'Upload Candidate',1,'Uploaded/Updated candidate: MUTAMBA MORIS (Index: 002127/024) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(354,'Upload Candidate',1,'Uploaded/Updated candidate: MUTESI FLAVIA (Index: 002127/025) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(355,'Upload Candidate',1,'Uploaded/Updated candidate: MUTESI SWABURAH (Index: 002127/026) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(356,'Upload Candidate',1,'Uploaded/Updated candidate: NABUKALU SAFINA (Index: 002127/027) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(357,'Upload Candidate',1,'Uploaded/Updated candidate: NABWIRE PRETTY FORTUNATE (Index: 002127/028) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(358,'Upload Candidate',1,'Uploaded/Updated candidate: NABIRE STELLA (Index: 002127/029) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(359,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA GLORIA (Index: 002127/030) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(360,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA MARIA (Index: 002127/031) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(361,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA RESTY (Index: 002127/032) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(362,'Upload Candidate',1,'Uploaded/Updated candidate: NAISIGA TRACY (Index: 002127/033) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(363,'Upload Candidate',1,'Uploaded/Updated candidate: NAKACHWA DOCUS (Index: 002127/034) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(364,'Upload Candidate',1,'Uploaded/Updated candidate: NAKISIGE SHEIRA (Index: 002127/035) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(365,'Upload Candidate',1,'Uploaded/Updated candidate: NAMBOGWE PATRICIA (Index: 002127/036) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(366,'Upload Candidate',1,'Uploaded/Updated candidate: NAMUKOSE AMINA (Index: 002127/037) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(367,'Upload Candidate',1,'Uploaded/Updated candidate: NANFUNA SHEIRA (Index: 002127/038) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(368,'Upload Candidate',1,'Uploaded/Updated candidate: NGOBI DENIS (Index: 002127/039) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(369,'Upload Candidate',1,'Uploaded/Updated candidate: NGOBI MAJORINE (Index: 002127/040) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(370,'Upload Candidate',1,'Uploaded/Updated candidate: NYIIRO AKIRAM (Index: 002127/041) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(371,'Upload Candidate',1,'Uploaded/Updated candidate: OBBO RONALD (Index: 002127/042) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(372,'Upload Candidate',1,'Uploaded/Updated candidate: SSEMBERA CALVIN JORDAN (Index: 002127/043) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(373,'Upload Candidate',1,'Uploaded/Updated candidate: TIBITONDWA DAMALI (Index: 002127/044) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(374,'Upload Candidate',1,'Uploaded/Updated candidate: SOMOKA JOVAN (Index: 002127/045) for school ID 4, exam_year_id 1','2025-07-28 23:30:03'),(375,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:30:32'),(376,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:30:32'),(377,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:30:35'),(378,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:30:35'),(379,'Upload Candidate',1,'Uploaded/Updated candidate: AJWANGI DINAH (Index: 002127/001) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(380,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE CLARE (Index: 002127/002) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(381,'Upload Candidate',1,'Uploaded/Updated candidate: BABIRYE MARION (Index: 002127/003) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(382,'Upload Candidate',1,'Uploaded/Updated candidate: BAKAAKI ISMA (Index: 002127/004) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(383,'Upload Candidate',1,'Uploaded/Updated candidate: BAKULIMYA RACHAEL (Index: 002127/005) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(384,'Upload Candidate',1,'Uploaded/Updated candidate: BASOOMYE BASHIRI (Index: 002127/006) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(385,'Upload Candidate',1,'Uploaded/Updated candidate: BAZAALE JACOB MULUNGI (Index: 002127/007) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(386,'Upload Candidate',1,'Uploaded/Updated candidate: BIRABWA AZIZA (Index: 002127/008) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(387,'Upload Candidate',1,'Uploaded/Updated candidate: ISABIRYE CYRUS (Index: 002127/009) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(388,'Upload Candidate',1,'Uploaded/Updated candidate: ISABIRYE FELIX (Index: 002127/010) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(389,'Upload Candidate',1,'Uploaded/Updated candidate: ISIIKO RAYMOND (Index: 002127/011) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(390,'Upload Candidate',1,'Uploaded/Updated candidate: KAGOYA SANIA (Index: 002127/012) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(391,'Upload Candidate',1,'Uploaded/Updated candidate: KALEMBE SHARIFAH (Index: 002127/013) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(392,'Upload Candidate',1,'Uploaded/Updated candidate: KAUDHA GLORIA (Index: 002127/014) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(393,'Upload Candidate',1,'Uploaded/Updated candidate: KIBOGO MUSA (Index: 002127/015) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(394,'Upload Candidate',1,'Uploaded/Updated candidate: KIRIMWA COLLINE (Index: 002127/016) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(395,'Upload Candidate',1,'Uploaded/Updated candidate: KIVEINUMA ABEL (Index: 002127/017) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(396,'Upload Candidate',1,'Uploaded/Updated candidate: KWEDUSA SARAH (Index: 002127/018) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(397,'Upload Candidate',1,'Uploaded/Updated candidate: MAGUNDA YOWERI (Index: 002127/019) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(398,'Upload Candidate',1,'Uploaded/Updated candidate: MATENDE SHAFIC (Index: 002127/020) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(399,'Upload Candidate',1,'Uploaded/Updated candidate: MIREMBE MARIAM (Index: 002127/021) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(400,'Upload Candidate',1,'Uploaded/Updated candidate: MUDOBI ISA (Index: 002127/022) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(401,'Upload Candidate',1,'Uploaded/Updated candidate: MUGOGO SHAKULU (Index: 002127/023) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(402,'Upload Candidate',1,'Uploaded/Updated candidate: MUTAMBA MORIS (Index: 002127/024) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(403,'Upload Candidate',1,'Uploaded/Updated candidate: MUTESI FLAVIA (Index: 002127/025) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(404,'Upload Candidate',1,'Uploaded/Updated candidate: MUTESI SWABURAH (Index: 002127/026) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(405,'Upload Candidate',1,'Uploaded/Updated candidate: NABUKALU SAFINA (Index: 002127/027) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(406,'Upload Candidate',1,'Uploaded/Updated candidate: NABWIRE PRETTY FORTUNATE (Index: 002127/028) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(407,'Upload Candidate',1,'Uploaded/Updated candidate: NABIRE STELLA (Index: 002127/029) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(408,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA GLORIA (Index: 002127/030) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(409,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA MARIA (Index: 002127/031) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(410,'Upload Candidate',1,'Uploaded/Updated candidate: NAIGAGA RESTY (Index: 002127/032) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(411,'Upload Candidate',1,'Uploaded/Updated candidate: NAISIGA TRACY (Index: 002127/033) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(412,'Upload Candidate',1,'Uploaded/Updated candidate: NAKACHWA DOCUS (Index: 002127/034) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(413,'Upload Candidate',1,'Uploaded/Updated candidate: NAKISIGE SHEIRA (Index: 002127/035) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(414,'Upload Candidate',1,'Uploaded/Updated candidate: NAMBOGWE PATRICIA (Index: 002127/036) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(415,'Upload Candidate',1,'Uploaded/Updated candidate: NAMUKOSE AMINA (Index: 002127/037) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(416,'Upload Candidate',1,'Uploaded/Updated candidate: NANFUNA SHEIRA (Index: 002127/038) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(417,'Upload Candidate',1,'Uploaded/Updated candidate: NGOBI DENIS (Index: 002127/039) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(418,'Upload Candidate',1,'Uploaded/Updated candidate: NGOBI MAJORINE (Index: 002127/040) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(419,'Upload Candidate',1,'Uploaded/Updated candidate: NYIIRO AKIRAM (Index: 002127/041) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(420,'Upload Candidate',1,'Uploaded/Updated candidate: OBBO RONALD (Index: 002127/042) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(421,'Upload Candidate',1,'Uploaded/Updated candidate: SSEMBERA CALVIN JORDAN (Index: 002127/043) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(422,'Upload Candidate',1,'Uploaded/Updated candidate: TIBITONDWA DAMALI (Index: 002127/044) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(423,'Upload Candidate',1,'Uploaded/Updated candidate: SOMOKA JOVAN (Index: 002127/045) for school ID 4, exam_year_id 1','2025-07-28 23:30:54'),(424,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:31:24'),(425,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:31:24'),(426,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:31:27'),(427,'Page Access',1,'Accessed page: View School: BUSALAMU PRIMARY SCHOOL','2025-07-28 23:31:27'),(428,'Dashboard Access',1,'Accessed dashboard','2025-07-28 23:32:00'),(429,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 23:32:00'),(430,'Dashboard Access',2,'Accessed dashboard','2025-07-28 23:32:15'),(431,'Dashboard Access',1,'Accessed dashboard','2025-07-28 23:34:24'),(432,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-28 23:34:24'),(433,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:34:29'),(434,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:34:29'),(435,'View School Access',1,'System Admin accessed view school page','2025-07-28 23:34:33'),(436,'Page Access',1,'Accessed page: View School: KIMANTO PRIMARY SCHOOL','2025-07-28 23:34:33'),(437,'Manage Targets Access',1,'Accessed manage targets page','2025-07-28 23:39:37'),(438,'Page Access',1,'Accessed page: Manage Daily Targets','2025-07-28 23:39:37'),(439,'Manage Targets Access',1,'Accessed manage targets page','2025-07-28 23:43:19'),(440,'Page Access',1,'Accessed page: Manage Daily Targets','2025-07-28 23:43:19'),(441,'Chat Access',1,'Accessed team chat page','2025-07-28 23:43:21'),(442,'Page Access',1,'Accessed page: Team Chat','2025-07-28 23:43:21'),(443,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:44:36'),(444,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:44:36'),(445,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:44:44'),(446,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:44:44'),(447,'Edit School Access',1,'System Admin accessed edit school page','2025-07-28 23:44:54'),(448,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:47:30'),(449,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:47:30'),(450,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 23:48:37'),(451,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 23:48:37'),(452,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 23:48:41'),(453,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 23:48:41'),(454,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 23:48:43'),(455,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 23:48:43'),(456,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 23:48:45'),(457,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 23:48:46'),(458,'Mark Save Error',2,'Error saving mark for candidate_id: 1, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:48:50'),(459,'Mark Save Error',2,'Error saving mark for candidate_id: 1, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:48:50'),(460,'Mark Save Error',2,'Error saving mark for candidate_id: 2, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:48:58'),(461,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-28 23:49:38'),(462,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-28 23:49:38'),(463,'Mark Save Error',2,'Error saving mark for candidate_id: 1, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:49:45'),(464,'Mark Save Error',2,'Error saving mark for candidate_id: 2, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:49:53'),(465,'Mark Save Error',2,'Error saving mark for candidate_id: 3, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:50:02'),(466,'Mark Save Error',2,'Error saving mark for candidate_id: 4, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:50:13'),(467,'Mark Save Error',2,'Error saving mark for candidate_id: 4, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-28 23:50:13'),(468,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:57:34'),(469,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:57:34'),(470,'Edit School Access',1,'System Admin accessed edit school page','2025-07-28 23:57:41'),(471,'Page Access',1,'Accessed page: Edit School','2025-07-28 23:57:41'),(472,'Edit School Access',1,'System Admin accessed edit school page','2025-07-28 23:58:12'),(473,'Page Access',1,'Accessed page: Edit School','2025-07-28 23:58:12'),(474,'Manage Schools Access',1,'System Admin accessed manage schools page','2025-07-28 23:58:21'),(475,'Page Access',1,'Accessed page: Manage Schools','2025-07-28 23:58:21'),(476,'Page Access',1,'Accessed page: Add Subcounty','2025-07-29 00:04:47'),(477,'Page Access',1,'Accessed page: Add Subcounty','2025-07-29 00:05:58'),(478,'Page Access',1,'Accessed page: Manage Subcounties','2025-07-29 00:06:00'),(479,'Set Targets Access',1,'Accessed set targets page','2025-07-29 00:06:13'),(480,'Page Access',1,'Accessed page: Set Daily Target','2025-07-29 00:06:13'),(481,'Set Targets Access',1,'Accessed set targets page','2025-07-29 00:06:18'),(482,'Page Access',1,'Accessed page: Set Daily Target','2025-07-29 00:06:18'),(483,'Set Targets Access',1,'Accessed set targets page','2025-07-29 00:06:44'),(484,'Page Access',1,'Accessed page: Set Daily Target','2025-07-29 00:06:44'),(485,'Dashboard Access',1,'Accessed dashboard','2025-07-29 00:06:59'),(486,'Dashboard Data Access',1,'Accessed dashboard data for exam_year_id: 1','2025-07-29 00:07:00'),(487,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-29 00:53:53'),(488,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-29 00:53:53'),(489,'Mark Save Error',2,'Error saving mark for candidate_id: 1, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-29 00:54:04'),(490,'Mark Save Error',2,'Error saving mark for candidate_id: 1, subject_id: 1, exam_year_id: 1: PROCEDURE ludeb.ComputeCandidateGrades does not exist','2025-07-29 00:54:04'),(491,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-29 00:54:13'),(492,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-29 00:54:13'),(493,'Dashboard Access',2,'Accessed dashboard','2025-07-29 00:55:50'),(494,'Dashboard Access',2,'Accessed dashboard','2025-07-29 00:55:56'),(495,'Dashboard Access',2,'Accessed dashboard','2025-07-29 00:57:26'),(496,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-29 00:57:31'),(497,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-29 00:57:31'),(498,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-29 00:57:34'),(499,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-29 00:57:34'),(500,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-29 00:57:38'),(501,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-29 00:57:38'),(502,'Mark Entry Page Access',NULL,'Accessed mark entry page','2025-07-29 00:57:40'),(503,'Mark Entry Page Access',2,'Accessed mark entry page','2025-07-29 00:57:40'),(504,'Compute Grades',2,'Computed grades for candidate ID 1 for exam year 1','2025-07-29 00:57:44'),(505,'Compute Results',2,'Computed results for candidate ID 1 for exam year 1','2025-07-29 00:57:44'),(506,'Mark Insert',2,'Saved mark for candidate: ASIO CHARITY MARY (ID: 1), subject_id: 1, exam_year_id: 1, mark: 57','2025-07-29 00:57:44'),(507,'Compute Grades',2,'Computed grades for candidate ID 1 for exam year 1','2025-07-29 00:57:44'),(508,'Compute Results',2,'Computed results for candidate ID 1 for exam year 1','2025-07-29 00:57:44'),(509,'Mark Update',2,'Saved mark for candidate: ASIO CHARITY MARY (ID: 1), subject_id: 1, exam_year_id: 1, mark: 57','2025-07-29 00:57:44'),(510,'Compute Grades',2,'Computed grades for candidate ID 2 for exam year 1','2025-07-29 00:57:47'),(511,'Compute Results',2,'Computed results for candidate ID 2 for exam year 1','2025-07-29 00:57:47'),(512,'Mark Insert',2,'Saved mark for candidate: ATIANG ESTHER (ID: 2), subject_id: 1, exam_year_id: 1, mark: 38','2025-07-29 00:57:47'),(513,'Compute Grades',2,'Computed grades for candidate ID 2 for exam year 1','2025-07-29 00:57:47'),(514,'Compute Results',2,'Computed results for candidate ID 2 for exam year 1','2025-07-29 00:57:47'),(515,'Mark Update',2,'Saved mark for candidate: ATIANG ESTHER (ID: 2), subject_id: 1, exam_year_id: 1, mark: 38','2025-07-29 00:57:47');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidate_results`
--

DROP TABLE IF EXISTS `candidate_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `candidate_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `aggregates` varchar(10) NOT NULL,
  `division` varchar(10) NOT NULL,
  `processed_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_candidate_results` (`candidate_id`,`exam_year_id`),
  KEY `processed_by` (`processed_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_candidate_id` (`candidate_id`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  KEY `idx_candidate_results_exam_year` (`exam_year_id`),
  CONSTRAINT `candidate_results_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `candidate_results_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `candidate_results_ibfk_3` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`),
  CONSTRAINT `candidate_results_ibfk_4` FOREIGN KEY (`processed_by`) REFERENCES `system_users` (`id`),
  CONSTRAINT `candidate_results_ibfk_5` FOREIGN KEY (`updated_by`) REFERENCES `system_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate_results`
--

LOCK TABLES `candidate_results` WRITE;
/*!40000 ALTER TABLE `candidate_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `candidate_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `index_number` varchar(255) NOT NULL,
  `candidate_name` varchar(255) NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_index_number_exam_year` (`index_number`,`exam_year_id`),
  KEY `idx_index_number` (`index_number`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  KEY `idx_candidates_exam_year` (`exam_year_id`),
  CONSTRAINT `candidates_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `candidates_ibfk_2` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidates`
--

LOCK TABLES `candidates` WRITE;
/*!40000 ALTER TABLE `candidates` DISABLE KEYS */;
INSERT INTO `candidates` VALUES (1,102,'950081/001','ASIO CHARITY MARY','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(2,102,'950081/002','ATIANG ESTHER','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(3,102,'950081/003','AYANGA PROSSY','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(4,102,'950081/004','BABIRYE SHAMIM NAKAGOLO','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(5,102,'950081/005','BAIDYE PRECIOUS GIFT','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(6,102,'950081/006','BANGI BENJAMIN','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(7,102,'950081/007','BEBINA SILAT','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(8,102,'950081/008','BIKUMBI ALPHA JOSHUA','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(9,102,'950081/009','BITIRA PROSSY','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(10,102,'950081/010','BULAGO SAMUEL','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(11,102,'950081/011','GALUBAALE JAMES','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(12,102,'950081/012','IGOYOOLA GILSOM','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(13,102,'950081/013','KADAKI EMMANUEL','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(14,102,'950081/014','KALULU KAMUYATI','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(15,102,'950081/015','KASUUBO NOVERT','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(16,102,'950081/016','KIRABO TRACY','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(17,102,'950081/017','KISAKYE CATHERINE','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(18,102,'950081/018','KISAMBIRA KELVIN','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(19,102,'950081/019','KWAGALA TRACY','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(20,102,'950081/020','LUKOLOBE YONAH','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(21,102,'950081/021','MAKIITA MARK PRAISE','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(22,102,'950081/022','MUNUNUZI TITUS','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(23,102,'950081/023','MUZAYA SHAMIRU','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(24,102,'950081/024','MUZAYA TREVIS','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(25,102,'950081/025','MWESIGWA GOSHENS','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(26,102,'950081/026','NAIGENDE MARIAM KISAKYE','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(27,102,'950081/027','NAIGWE ESTHER','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(28,102,'950081/028','NAKABUYE HAIRAT','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(29,102,'950081/029','NAKASANGO SAYIDA','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(30,102,'950081/030','NAMUGANZA MILLY','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(31,102,'950081/031','NANGOBI DAPHINE','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(32,102,'950081/032','NANKWANGA SHARON','Female',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(33,102,'950081/033','OKUMU WISDOM','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(34,102,'950081/034','SSUUBI KELLY','Male',1,'2025-07-28 23:18:00','2025-07-28 23:18:00'),(35,4,'002127/001','AJWANGI DINAH','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(36,4,'002127/002','BABIRYE CLARE','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(37,4,'002127/003','BABIRYE MARION','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(38,4,'002127/004','BAKAAKI ISMA','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(39,4,'002127/005','BAKULIMYA RACHAEL','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(40,4,'002127/006','BASOOMYE BASHIRI','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(41,4,'002127/007','BAZAALE JACOB MULUNGI','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(42,4,'002127/008','BIRABWA AZIZA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(43,4,'002127/009','ISABIRYE CYRUS','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(44,4,'002127/010','ISABIRYE FELIX','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(45,4,'002127/011','ISIIKO RAYMOND','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(46,4,'002127/012','KAGOYA SANIA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(47,4,'002127/013','KALEMBE SHARIFAH','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(48,4,'002127/014','KAUDHA GLORIA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(49,4,'002127/015','KIBOGO MUSA','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(50,4,'002127/016','KIRIMWA COLLINE','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(51,4,'002127/017','KIVEINUMA ABEL','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(52,4,'002127/018','KWEDUSA SARAH','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(53,4,'002127/019','MAGUNDA YOWERI','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(54,4,'002127/020','MATENDE SHAFIC','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(55,4,'002127/021','MIREMBE MARIAM','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(56,4,'002127/022','MUDOBI ISA','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(57,4,'002127/023','MUGOGO SHAKULU','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(58,4,'002127/024','MUTAMBA MORIS','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(59,4,'002127/025','MUTESI FLAVIA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(60,4,'002127/026','MUTESI SWABURAH','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(61,4,'002127/027','NABUKALU SAFINA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(62,4,'002127/028','NABWIRE PRETTY FORTUNATE','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(63,4,'002127/029','NABIRE STELLA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(64,4,'002127/030','NAIGAGA GLORIA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(65,4,'002127/031','NAIGAGA MARIA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(66,4,'002127/032','NAIGAGA RESTY','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(67,4,'002127/033','NAISIGA TRACY','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(68,4,'002127/034','NAKACHWA DOCUS','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(69,4,'002127/035','NAKISIGE SHEIRA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(70,4,'002127/036','NAMBOGWE PATRICIA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(71,4,'002127/037','NAMUKOSE AMINA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(72,4,'002127/038','NANFUNA SHEIRA','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(73,4,'002127/039','NGOBI DENIS','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(74,4,'002127/040','NGOBI MAJORINE','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(75,4,'002127/041','NYIIRO AKIRAM','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(76,4,'002127/042','OBBO RONALD','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(77,4,'002127/043','SSEMBERA CALVIN JORDAN','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(78,4,'002127/044','TIBITONDWA DAMALI','Female',1,'2025-07-28 23:29:21','2025-07-28 23:29:21'),(79,4,'002127/045','SOMOKA JOVAN','Male',1,'2025-07-28 23:29:21','2025-07-28 23:29:21');
/*!40000 ALTER TABLE `candidates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_targets`
--

DROP TABLE IF EXISTS `daily_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_targets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_date` date NOT NULL,
  `target_entries` int(11) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_daily_targets` (`target_date`,`exam_year_id`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  CONSTRAINT `daily_targets_ibfk_1` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_targets`
--

LOCK TABLES `daily_targets` WRITE;
/*!40000 ALTER TABLE `daily_targets` DISABLE KEYS */;
INSERT INTO `daily_targets` VALUES (1,'2025-07-28',2400,1,'2025-07-28 20:25:55','2025-07-28 20:25:55');
/*!40000 ALTER TABLE `daily_targets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `districts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `district_name` varchar(100) NOT NULL,
  `district_code` varchar(20) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `district_code` (`district_code`),
  KEY `idx_district_code` (`district_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,'Luuka District','102','2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_years`
--

DROP TABLE IF EXISTS `exam_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_years` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_year` year(4) NOT NULL,
  `status` enum('Active','Not Active') DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exam_year` (`exam_year`),
  KEY `idx_exam_year` (`exam_year`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_years`
--

LOCK TABLES `exam_years` WRITE;
/*!40000 ALTER TABLE `exam_years` DISABLE KEYS */;
INSERT INTO `exam_years` VALUES (1,2025,'Active','2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `exam_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_range_from` int(11) NOT NULL,
  `aggregate_range_to` int(11) NOT NULL,
  `division` varchar(10) NOT NULL,
  `conditions` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
INSERT INTO `grades` VALUES (1,4,12,'Division 1','{\"must_pass_all\": true, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8, \"exceptions\": [{\"subject\": \"ENG\", \"grade\": 9, \"demote_to\": \"Division 2\"}, {\"subject\": \"MTC\", \"grade\": 9, \"demote_to\": \"Division 2\"}]}','2025-07-28 20:15:03','2025-07-28 20:15:03'),(2,13,23,'Division 2','{\"min_pass_subjects\": 3, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8, \"exceptions\": [{\"subjects_failed\": [\"ENG\", \"MTC\"], \"grade\": 9, \"demote_to\": \"Division 3\"}]}','2025-07-28 20:15:03','2025-07-28 20:15:03'),(3,24,28,'Division 3','{\"min_pass_subjects\": 3, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8}','2025-07-28 20:15:03','2025-07-28 20:15:03'),(4,29,29,'Division 3','{\"min_pass_subjects\": 3, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8, \"must_include\": [\"ENG\", \"MTC\"], \"must_include_condition\": \"at least one\"}','2025-07-28 20:15:03','2025-07-28 20:15:03'),(5,29,32,'Division 4','{\"min_pass_subjects\": 2, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8}','2025-07-28 20:15:03','2025-07-28 20:15:03'),(6,33,33,'Division 4','{\"min_pass_subjects\": 2, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8, \"must_include\": [\"ENG\", \"MTC\"], \"must_include_condition\": \"at least one\"}','2025-07-28 20:15:03','2025-07-28 20:15:03'),(7,33,36,'Ungraded','{\"max_pass_subjects\": 1, \"subjects\": [\"ENG\", \"MTC\", \"SCI\", \"SST\"], \"max_grade_per_subject\": 8}','2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grading`
--

DROP TABLE IF EXISTS `grading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grading` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_from` int(11) NOT NULL,
  `range_to` int(11) NOT NULL,
  `grade` varchar(2) NOT NULL,
  `score` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grading`
--

LOCK TABLES `grading` WRITE;
/*!40000 ALTER TABLE `grading` DISABLE KEYS */;
INSERT INTO `grading` VALUES (1,0,20,'F9',9,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(2,21,34,'P8',8,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(3,35,49,'P7',7,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(4,50,59,'C6',6,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(5,60,69,'C5',5,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(6,70,79,'C4',4,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(7,80,84,'C3',3,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(8,85,89,'D2',2,'2025-07-28 20:15:03','2025-07-28 20:15:03'),(9,90,100,'D1',1,'2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `grading` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marks`
--

DROP TABLE IF EXISTS `marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `mark` int(11) NOT NULL CHECK (`mark` >= 0 and `mark` <= 100),
  `status` enum('PRESENT','ABSENT') DEFAULT 'PRESENT',
  `submitted_by` int(11) NOT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_marks` (`candidate_id`,`subject_id`,`exam_year_id`),
  KEY `submitted_by` (`submitted_by`),
  KEY `edited_by` (`edited_by`),
  KEY `idx_candidate_id` (`candidate_id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  KEY `idx_marks_status` (`status`),
  KEY `idx_marks_exam_year_candidate` (`exam_year_id`,`candidate_id`),
  CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `marks_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `marks_ibfk_3` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `marks_ibfk_4` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`),
  CONSTRAINT `marks_ibfk_5` FOREIGN KEY (`submitted_by`) REFERENCES `system_users` (`id`),
  CONSTRAINT `marks_ibfk_6` FOREIGN KEY (`edited_by`) REFERENCES `system_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marks`
--

LOCK TABLES `marks` WRITE;
/*!40000 ALTER TABLE `marks` DISABLE KEYS */;
INSERT INTO `marks` VALUES (11,1,1,102,1,57,'PRESENT',2,2,'2025-07-29 00:57:44','2025-07-29 00:57:44'),(12,2,1,102,1,38,'PRESENT',2,2,'2025-07-29 00:57:47','2025-07-29 00:57:47');
/*!40000 ALTER TABLE `marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `mark` int(11) NOT NULL CHECK (`mark` >= 0 and `mark` <= 100),
  `score` int(11) NOT NULL CHECK (`score` >= 1 and `score` <= 9),
  `processed_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `processed_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_results` (`candidate_id`,`subject_id`,`exam_year_id`),
  KEY `processed_by` (`processed_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_candidate_id` (`candidate_id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  KEY `idx_results_exam_year_candidate` (`exam_year_id`,`candidate_id`),
  CONSTRAINT `results_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `results_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `results_ibfk_3` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `results_ibfk_4` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`),
  CONSTRAINT `results_ibfk_5` FOREIGN KEY (`processed_by`) REFERENCES `system_users` (`id`),
  CONSTRAINT `results_ibfk_6` FOREIGN KEY (`updated_by`) REFERENCES `system_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results`
--

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES (1,1,1,102,1,57,6,2,NULL,'2025-07-29 00:57:44','2025-07-29 00:57:44'),(2,2,1,102,1,38,7,2,NULL,'2025-07-29 00:57:47','2025-07-29 00:57:47');
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_results`
--

DROP TABLE IF EXISTS `school_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `candidate_index_number` varchar(255) NOT NULL,
  `candidate_name` varchar(255) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `marks` int(11) NOT NULL CHECK (`marks` >= 0 and `marks` <= 100),
  `grade` varchar(2) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_school_results` (`candidate_id`,`subject_code`,`exam_year_id`),
  KEY `school_id` (`school_id`),
  KEY `subject_code` (`subject_code`),
  KEY `idx_candidate_index_number` (`candidate_index_number`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  KEY `idx_school_results_exam_year` (`exam_year_id`),
  CONSTRAINT `school_results_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `school_results_ibfk_2` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `school_results_ibfk_3` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`),
  CONSTRAINT `school_results_ibfk_4` FOREIGN KEY (`subject_code`) REFERENCES `subjects` (`code`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_results`
--

LOCK TABLES `school_results` WRITE;
/*!40000 ALTER TABLE `school_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `school_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_types`
--

DROP TABLE IF EXISTS `school_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_types`
--

LOCK TABLES `school_types` WRITE;
/*!40000 ALTER TABLE `school_types` DISABLE KEYS */;
INSERT INTO `school_types` VALUES (1,'Government','2025-07-28 20:15:03','2025-07-28 21:06:04'),(2,'Private','2025-07-28 20:15:03','2025-07-28 21:06:04');
/*!40000 ALTER TABLE `school_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `center_no` varchar(20) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `subcounty_id` int(11) NOT NULL,
  `school_type_id` int(11) NOT NULL,
  `status` enum('Active','Not Active') DEFAULT 'Active',
  `results_status` enum('Not Declared','Partially Declared','Declared') DEFAULT 'Not Declared',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `center_no` (`center_no`),
  KEY `school_type_id` (`school_type_id`),
  KEY `idx_center_no` (`center_no`),
  KEY `idx_subcounty_id` (`subcounty_id`),
  CONSTRAINT `schools_ibfk_1` FOREIGN KEY (`subcounty_id`) REFERENCES `subcounties` (`id`),
  CONSTRAINT `schools_ibfk_2` FOREIGN KEY (`school_type_id`) REFERENCES `school_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES (1,'002123','KIMANTO PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(2,'002124','BUDONDO PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(3,'002126','LUKUNHU MOSLEM PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(4,'002127','BUSALAMU PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(5,'002128','TABINGWA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(6,'002130','BUWOLOGOMA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(7,'002131','BUKADDE PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(8,'002132','NDHOYA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(9,'002134','BIGUNHO PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(10,'002135','KIROBA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(11,'002136','NAKABONDO PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(12,'002137','BUDOMA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(13,'002138','WALYEMBWA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(14,'002139','BUKANGA PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(15,'002140','NAMUKUBEMBE PRIMARY SCHOOL',6,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(16,'002141','BUKANHA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(17,'002142','BUKYANGWA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(18,'002143','BUKOOVA ST.MARY\'S PRI. SCHOOL',5,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 23:58:12'),(19,'002144','BUSANDA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(20,'002145','ST.THOMAS MUKUTU PRI. SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(21,'002147','NAIRIKA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(22,'002148','NAIGOBYA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(23,'002149','BUSAKU PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(24,'002150','KIRIMWA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(25,'002151','NAMULANDA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(26,'002152','GWEMBUZI PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(27,'002153','NAWANSEGA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(28,'002156','BUDHABANGULA PRIMARY SCHOOL',1,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(29,'002157','NAMUMERA PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(30,'002158','BUGONYOKA PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(31,'002160','NABITAAMA PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(32,'002161','BUKENDI PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(33,'002162','BUGABULA PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(34,'002163','MAWEMBE PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(35,'002165','KIYUNGA PRIMARY SCHOOL',1,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(36,'002166','KAMWIRUNGU PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(37,'002167','KITWEKYAMBOGO PRIMARY SCHOOL',1,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(38,'002170','BUYUNZE PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(39,'002171','BUSALA PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(40,'002172','NAKABUGU PRIMARY SCHOOL',3,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(41,'002173','IKUMBYA PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(42,'002174','IKUMBYA CATHOLIC PRI. SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(43,'002176','BUGAMBO PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(44,'002177','BUDHUUBA PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(45,'002178','WANDAGO PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(46,'002179','BUNAFU PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(47,'002180','NAWAKA PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(48,'002181','NTAYIGIRWA PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(49,'002182','BUKOBBO PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(50,'002183','IRONGO PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(51,'002184','LAMBALA PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(52,'002185','NAIMULI PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(53,'002187','KALYOWA PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(54,'002188','NAKAVUMA PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(55,'002189','NKANDAKULYOWA PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(56,'002191','KIWALAZI PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(57,'002192','NAKABAALE PRIMARY SCHOOL',8,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(58,'002194','BUTOGONYA PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(59,'002195','BUYEMBA PRIMARY SCHOOL',7,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(60,'002196','BUWANDA PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(61,'002197','NAWANDYO PRIMARY SCHOOL(LUUKA)',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(62,'002198','BUGOMBA PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(63,'002199','BUYOOLA PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(64,'002200','IKONIA PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(65,'002202','NABIKUYI PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(66,'002203','NAMAGERA PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(67,'002204','NAWAMPITI PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(68,'002205','KITUUTO PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(69,'002208','NAWANKOMPE PRIMARY SCHOOL',11,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(70,'002209','BUSIIRO PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(71,'002211','BUSIIRO MUSLIM PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(72,'002212','BUTIMBWA PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(73,'002213','NAMAKAKALE PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(74,'002214','WAIBUGA MUSLIM PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(75,'002216','WAIBUGA PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(76,'002217','BUWIIRI PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(77,'002218','KAKUMBI PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(78,'002219','NAMADOPE PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(79,'002221','BULANGA PRIMARY SCHOOL',10,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(80,'002222','MAUNDO PRIMARY SCHOOL',10,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(81,'002223','BULANGA NAHADHAT PRI. SCHOOL',10,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(82,'002225','WALIBO PRIMARY SCHOOL',12,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(83,'080012','BUDHAANA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(84,'080013','KIYUNGA PARENTS PRIMARY SCHOOL',1,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(85,'080048','BUYOGA PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(86,'080071','BULAWA PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(87,'080072','KYANVUMA PRIMARY SCHOOL',8,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(88,'080073','BUGONZA PRIMARY SCHOOL',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(89,'080079','ROADSIDE PRIMARY SCHOOL',10,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(90,'080093','ST.KIZITO KAWANGA P/S',2,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(91,'080095','NABYOTO PRIMARY SCHOOL',5,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(92,'080104','ST.ALICE BUDOMA STAR PRIMARY SCHOOL',6,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(93,'080125','NABIMOGO PRIMARY SCHOOL',4,1,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(94,'080152','SAAWE VICTORY PRIMARY SCHOOL',10,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(95,'950002','IKONIA PARENTS PRIMARY SCHOOL',11,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(96,'950003','MARIAM MEMORIAL PRIMARY SCHOOL',10,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(97,'950054','HEALING CHILDREN SCHOOL',12,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(98,'950063','NEW HOPE PRIMARY SCHOOL',6,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(99,'950069','NAMULANDA MODEL PRIMARY SCHOOL',4,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(100,'950073','BUDHUUBA MODERN PRIMARY SCHOOL',2,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(101,'950080','SHALOM CHRISTIAN BOARDING P/S',6,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(102,'950081','B. M PRIMARY SCHOOL',1,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(103,'950082','EDEN JUNIOR SCHOOL,KIYUNGA',1,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(104,'950094','BULIKE COMMUNITY SCHOOL',2,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(105,'950101','ST.ALOYSIOUS PRIMARY SCHOOL,LUUKA',7,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24'),(106,'950180','KIYUNGA VILLAGE PRIMARY SCHOOL',1,2,'Active','Not Declared','2025-07-28 21:06:24','2025-07-28 21:06:24');
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `board_name` varchar(100) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `grading_scale` varchar(50) NOT NULL DEFAULT 'Standard',
  `contact_email` varchar(100) DEFAULT NULL,
  `district_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exam_year_id` (`exam_year_id`),
  KEY `idx_district_id` (`district_id`),
  CONSTRAINT `settings_ibfk_1` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`),
  CONSTRAINT `settings_ibfk_2` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'LUUKA DISTRICT PRIMARY MOCK EXAMINATIONS BOARD',1,NULL,'Standard','ludeb@gmail.com',1,'2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcounties`
--

DROP TABLE IF EXISTS `subcounties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcounties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `district_id` int(11) NOT NULL,
  `subcounty` varchar(255) NOT NULL,
  `constituency` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `district_id` (`district_id`),
  KEY `idx_subcounty` (`subcounty`),
  CONSTRAINT `subcounties_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcounties`
--

LOCK TABLES `subcounties` WRITE;
/*!40000 ALTER TABLE `subcounties` DISABLE KEYS */;
INSERT INTO `subcounties` VALUES (1,1,'Luuka Town Council','Luuka North','2025-07-28 20:15:03','2025-07-28 20:15:03'),(2,1,'Ikumbya','Luuka North','2025-07-28 20:15:03','2025-07-28 20:15:03'),(3,1,'Bulongo','Luuka North','2025-07-28 20:15:03','2025-07-28 20:15:03'),(4,1,'Bukoma','Luuka North','2025-07-28 20:15:03','2025-07-28 20:15:03'),(5,1,'Bukoova Town Council','Luuka North','2025-07-28 20:15:03','2025-07-28 20:15:03'),(6,1,'Bukanga','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03'),(7,1,'Irongo','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03'),(8,1,'Kyanvuma Town Council','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03'),(9,1,'Busalamu Town Council','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03'),(10,1,'Bulanga Town Council','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03'),(11,1,'Nawampiti','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03'),(12,1,'Waibuga','Luuka South','2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `subcounties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcounty_results`
--

DROP TABLE IF EXISTS `subcounty_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcounty_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subcounty_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `candidate_index_number` varchar(255) NOT NULL,
  `candidate_name` varchar(255) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `marks` int(11) NOT NULL CHECK (`marks` >= 0 and `marks` <= 100),
  `grade` varchar(2) NOT NULL,
  `exam_year_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_subcounty_results` (`candidate_id`,`subject_code`,`exam_year_id`),
  KEY `subcounty_id` (`subcounty_id`),
  KEY `subject_code` (`subject_code`),
  KEY `idx_candidate_index_number` (`candidate_index_number`),
  KEY `idx_exam_year_id` (`exam_year_id`),
  KEY `idx_subcounty_results_exam_year` (`exam_year_id`),
  CONSTRAINT `subcounty_results_ibfk_1` FOREIGN KEY (`subcounty_id`) REFERENCES `subcounties` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subcounty_results_ibfk_2` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subcounty_results_ibfk_3` FOREIGN KEY (`exam_year_id`) REFERENCES `exam_years` (`id`),
  CONSTRAINT `subcounty_results_ibfk_4` FOREIGN KEY (`subject_code`) REFERENCES `subjects` (`code`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcounty_results`
--

LOCK TABLES `subcounty_results` WRITE;
/*!40000 ALTER TABLE `subcounty_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `subcounty_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'English','ENG','2025-07-28 20:15:03','2025-07-28 20:15:03'),(2,'Mathematics','MTC','2025-07-28 20:15:03','2025-07-28 20:15:03'),(3,'Science','SCI','2025-07-28 20:15:03','2025-07-28 20:15:03'),(4,'Social Studies','SST','2025-07-28 20:15:03','2025-07-28 20:15:03');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_users`
--

DROP TABLE IF EXISTS `system_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('System Admin','Examination Administrator','Data Entrant') NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `status` enum('Active','Invalid') DEFAULT 'Active',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `school_id` (`school_id`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  CONSTRAINT `system_users_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_users`
--

LOCK TABLES `system_users` WRITE;
/*!40000 ALTER TABLE `system_users` DISABLE KEYS */;
INSERT INTO `system_users` VALUES (1,'Admin','admin@ludeb.ac','$2y$10$TC.oKI14xcN67MYoKCJfhuHQAOY0UHFKCpxGJv3RHkVwNuh7CrxcC','System Admin',NULL,'Active','2025-07-28 19:25:03','2025-07-28 20:15:04','2025-07-28 20:25:03'),(2,'Nelson','nelson@ludeb.ac','$2y$10$w1y9oeAMmxBUeP94BGuIg.wb2vSRz.iFFnydJgI/EOty2h1NSShEm','Data Entrant',NULL,'Active','2025-07-28 19:19:18','2025-07-28 20:15:04','2025-07-28 20:19:18');
/*!40000 ALTER TABLE `system_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `uploaded_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_uploaded_by` (`uploaded_by`),
  CONSTRAINT `uploads_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE SET NULL,
  CONSTRAINT `uploads_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `system_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
INSERT INTO `uploads` VALUES (1,102,'B._M_PRIMARY_SCHOOL_1753733880.xlsx','2025-07-28 23:18:00',1),(2,4,'BUSALAMU_PRIMARY_SCHOOL_1753734561.xlsx','2025-07-28 23:29:21',1),(3,4,'BUSALAMU_PRIMARY_SCHOOL_1753734603.xlsx','2025-07-28 23:30:03',1),(4,4,'BUSALAMU_PRIMARY_SCHOOL_1753734653.xlsx','2025-07-28 23:30:54',1);
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-29  1:07:23
